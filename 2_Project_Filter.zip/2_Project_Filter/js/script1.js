var el = document.querySelector('#filter');
var el2 = document.querySelector('section');

el.onclick = function() {
  el2.classList.toggle('list');
}



