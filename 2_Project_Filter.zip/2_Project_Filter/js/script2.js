var el = document.querySelector(".rotate");

el.onclick = function(){
    el.classList.toggle("down");
}